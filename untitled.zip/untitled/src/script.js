// Selecting all sections with class of section
const sections = document.querySelectorAll('.section')

// On click event for each section 
sections.forEach((section)=>{
    section.addEventListener('click',()=>{
    // remove active class from all another section 
    // and add it to the selected section
        sections.forEach((section) => {
            section.classList.remove('active')
        })
        section.classList.add('active')
    })
})

// Hide all elements with class="containerTab", except for the one that matches the clickable grid column
function openTab(tabName) {
  var i, x;
  x = document.getElementsByClassName("containerTab");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  document.getElementById(tabName).style.display = "block";
}

var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.display === "block") {
      content.style.display = "none";
    } else {
      content.style.display = "block";
    }
  });
}